<?php
/**
 * Induxo Child Theme - Spenglerei Peters
 * Modern Artisan Glassmorphism Design System
 */

if (!defined('ABSPATH')) {
    exit;
}

// Enqueue parent and child theme styles
function induxo_child_enqueue_styles() {
    $parent_style = 'induxo-parent-style';

    wp_enqueue_style($parent_style, get_template_directory_uri() . '/style.css');
    wp_enqueue_style('induxo-child-style', get_stylesheet_uri(), array($parent_style), wp_get_theme()->get('Version'));

    // Google Fonts - Manrope
    wp_enqueue_style('manrope-font', 'https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'induxo_child_enqueue_styles');

// Add glassmorphism body class
function induxo_child_body_classes($classes) {
    $classes[] = 'glassmorphism-theme';
    $classes[] = 'modern-artisan';
    return $classes;
}
add_action('body_class', 'induxo_child_body_classes');

// Register navigation menus
function induxo_child_register_menus() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'induxo-child'),
        'footer' => __('Footer Menu', 'induxo-child'),
    ));
}
add_action('after_setup_theme', 'induxo_child_register_menus');

// Enable featured images
add_theme_support('post-thumbnails');
add_theme_support('title-tag');
add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));

// Custom logo support
add_theme_support('custom-logo', array(
    'height' => 100,
    'width' => 400,
    'flex-height' => true,
    'flex-width' => true,
));

// Elementor support
add_action('after_setup_theme', function() {
    add_theme_support('elementor');
});

// Cleanup head
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');