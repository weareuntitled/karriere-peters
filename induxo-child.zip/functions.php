<?php
/**
 * Induxo Child Theme Functions
 * Spenglerei Peters
 */

if (!defined('ABSPATH')) exit;

/**
 * Enqueue parent and child theme styles
 */
function induxo_child_enqueue_styles() {
    // Parent theme styles
    $parent_style = 'parent-style';
    wp_enqueue_style($parent_style, get_template_directory_uri() . '/style.css');
    
    // Child theme styles (after parent to override)
    wp_enqueue_style('induxo-child-style', get_stylesheet_uri(), array($parent_style), wp_get_theme()->get('Version'));
}
add_action('wp_enqueue_scripts', 'induxo_child_enqueue_styles');

/**
 * Add Google Fonts - DM Sans
 */
function induxo_child_google_fonts() {
    wp_enqueue_style('dm-sans-font', 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'induxo_child_google_fonts');

/**
 * Register Custom Post Types
 * (Included directly - kann auch als separates Plugin genutzt werden)
 */
function spenglerei_register_cpts() {
    // Services
    register_post_type('service', [
        'labels' => [
            'name' => 'Dienstleistungen',
            'singular_name' => 'Dienstleistung',
            'add_new' => 'Neue Dienstleistung',
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-building',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_menu' => true,
        'rewrite' => ['slug' => 'dienstleistungen'],
    ]);

    // Projects
    register_post_type('project', [
        'labels' => [
            'name' => 'Projekte',
            'singular_name' => 'Projekt',
            'add_new' => 'Neues Projekt',
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-images-alt2',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_menu' => true,
        'rewrite' => ['slug' => 'projekte'],
    ]);

    // Jobs
    register_post_type('job', [
        'labels' => [
            'name' => 'Stellenangebote',
            'singular_name' => 'Stelle',
            'add_new' => 'Neue Stelle',
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-id',
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_menu' => true,
        'rewrite' => ['slug' => 'karriere'],
    ]);

    // Team Members
    register_post_type('team_member', [
        'labels' => [
            'name' => 'Team',
            'singular_name' => 'Team-Mitglied',
            'add_new' => 'Neues Team-Mitglied',
        ],
        'public' => true,
        'menu_icon' => 'dashicons-groups',
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_menu' => true,
        'rewrite' => ['slug' => 'team'],
    ]);
}
add_action('init', 'spenglerei_register_cpts');

/**
 * Flush rewrite rules on theme activation
 */
function induxo_child_flush_rewrite() {
    spenglerei_register_cpts();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'induxo_child_flush_rewrite');

/**
 * Custom body classes for Glassmorphism
 */
function induxo_child_body_classes($classes) {
    $classes[] = 'glassmorphism-theme';
    return $classes;
}
add_filter('body_class', 'induxo_child_body_classes');

/**
 * Remove parent theme's default fonts if needed
 * (Falls Induxo eigene Fonts lädt die wir nicht wollen)
 */
function induxo_child_dequeue_fonts() {
    // Falls nötig: wp_dequeue_style('parent-font-handle');
}
add_action('wp_enqueue_scripts', 'induxo_child_dequeue_fonts', 20);

/**
 * Add theme support
 */
function induxo_child_theme_support() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    
    // Elementor Support
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'induxo_child_theme_support');