<?php
/**
 * Induxo Child Theme - Spenglerei Peters
 * Liquid Glass Design System (iOS 26 Adaptation)
 * Font: DM Sans via Google Fonts (proper enqueue)
 */

if (!defined('ABSPATH')) {
    exit;
}

// Enqueue parent and child theme styles + DM Sans font
function induxo_child_enqueue_assets() {
    $parent_style = 'induxo-parent-style';

    // Parent theme style
    wp_enqueue_style($parent_style, get_template_directory_uri() . '/style.css');

    // Child theme style (depends on parent)
    wp_enqueue_style(
        'induxo-child-style',
        get_stylesheet_uri(),
        array($parent_style),
        wp_get_theme()->get('Version')
    );

    // DM Sans - properly enqueued (not @import)
    wp_enqueue_style(
        'dm-sans-font',
        'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap',
        array(),
        null
    );
}
add_action('wp_enqueue_scripts', 'induxo_child_enqueue_assets');

// Add Liquid Glass body classes
function induxo_child_body_classes($classes) {
    $classes[] = 'liquid-glass-theme';
    $classes[] = 'ios-26-design';
    $classes[] = 'dm-sans-active';
    return $classes;
}
add_action('body_class', 'induxo_child_body_classes');

// Register navigation menus
function induxo_child_register_menus() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'induxo-child'),
        'footer'  => __('Footer Menu', 'induxo-child'),
    ));
}
add_action('after_setup_theme', 'induxo_child_register_menus');

// Theme supports
add_theme_support('post-thumbnails');
add_theme_support('title-tag');
add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
add_theme_support('custom-logo', array(
    'height'      => 100,
    'width'       => 400,
    'flex-height' => true,
    'flex-width'  => true,
));

// Elementor support
add_action('after_setup_theme', function() {
    add_theme_support('elementor');
});

// Cleanup
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');

// Force DM Sans via inline CSS (fallback + higher specificity)
function induxo_child_inline_font() {
    echo '<style id="dm-sans-force">:root{--font-family:"DM Sans",sans-serif}html,body,button,input,select,textarea{font-family:var(--font-family)!important}</style>';
}
add_action('wp_head', 'induxo_child_inline_font', 1);